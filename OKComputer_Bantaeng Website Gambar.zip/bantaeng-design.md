# Bantaeng Website Design Concept

## 1. Design Philosophy

### Overall Visual Direction

A design vision of "Modern Editorial," blending the authentic, human-centric storytelling of National Geographic with the clean, structured layouts of Monocle magazine. The aesthetic uses an earthy color palette and organic textures to reflect Bantaeng's natural landscape, creating a digital experience that feels both sophisticated and grounded, like a premium travel publication.

### Content Density

High-Medium Density. Each page will balance rich information with compelling visuals. Expect 3-5 key points per section, with a layout that uses around 20% whitespace to ensure readability without sacrificing depth, similar to a feature in a travel magazine.

## 2. Color System

**Primary Colors**

- Background color: #F5F5DC (Cream - warm, natural base)
- Primary color: #8B4513 (Saddle Brown - earth tone for main elements)
- Secondary color: #9CAF88 (Sage Green - natural accent)
- Accent color: #E2725B (Terracotta - warm highlight)

**Text Colors**

- Dark text (for light backgrounds): #2C3E50 (Deep Navy - readable on cream)
- Light text (for dark backgrounds): #F5F5DC (Cream - for overlays on images)

## 3. Font Design

**Heading Fonts**

- English fonts
  - Oranienbaum (A high-contrast serif with elegant lines, evoking classic editorial style - for main titles)
  - Quattrocento (A classic serif with strong, clear letterforms, adding historical gravitas - for section headers)

**Body Fonts**

- English fonts
  - Quattrocento Sans (A clean, warm, and highly readable sans-serif, perfect for body text - primary body)
  - Sorts Mill Goudy (An elegant, classic serif font that offers excellent readability for text blocks - secondary body)

## 4. Image Style

Utilize high-quality, documentary-style photography with warm, natural light. Images should feel authentic and candid, focusing on landscapes, local culture, and architectural details. A slightly desaturated color grade with an emphasis on earth tones will reinforce the editorial and human-centric aesthetic.
